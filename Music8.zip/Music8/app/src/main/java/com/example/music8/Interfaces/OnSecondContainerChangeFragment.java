package com.example.music8.Interfaces;

public interface OnSecondContainerChangeFragment {
    void secondContainerChangeFragment(int tabnumber);
}
