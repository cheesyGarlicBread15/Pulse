package com.example.music8.Fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.music8.Playlist.Playlist;
import com.example.music8.Playlist.PlaylistContainer;
import com.example.music8.R;


public class PlaylistDetailsFragment extends Fragment {
    private TextView plName, numOfTracks;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_playlist_details, container, false);

        //        Register touches only in this fragment, not pass through it
        view.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_MOVE){
                    return false;
                }
                return true;
            }
        });

        plName = view.findViewById(R.id.playlist_details_name);
        numOfTracks = view.findViewById(R.id.playlsit_details_num_tracks);

        if (getArguments() != null){
            setupPlaylist();
        }

        return view;
    }

    private void setupPlaylist(){
        Playlist selectedPlaylist = ((PlaylistContainer) getArguments().getParcelable("selected_playlist")).getPlaylist();
        plName.setText(selectedPlaylist.getPlaylistName());
        numOfTracks.setText(String.valueOf(selectedPlaylist.getPlaylistTracks().size()));

    }
}