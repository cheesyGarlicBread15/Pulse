package com.example.music8.Interfaces;

public interface OnPlaylistAddedListener {
    public void onPlaylistAdded();
}
