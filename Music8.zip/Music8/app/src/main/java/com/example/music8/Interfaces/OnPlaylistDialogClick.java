package com.example.music8.Interfaces;

import android.content.Context;

import com.example.music8.Playlist.PlaylistContainer;

public interface OnPlaylistDialogClick {
    public void onPlaylistDialogClick(PlaylistContainer playlistContainer, int position, Context context);
}
