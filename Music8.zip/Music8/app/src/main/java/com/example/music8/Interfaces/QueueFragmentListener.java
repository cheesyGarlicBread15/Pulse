package com.example.music8.Interfaces;

public interface QueueFragmentListener {
    public void onQueueFragmentReady();
}
