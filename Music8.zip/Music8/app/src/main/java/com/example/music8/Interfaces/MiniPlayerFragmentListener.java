package com.example.music8.Interfaces;

public interface MiniPlayerFragmentListener {
    public void onMiniPlayerFragmentReady();
}
